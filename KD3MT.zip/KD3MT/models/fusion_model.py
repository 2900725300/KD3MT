import torch
import torch.nn as nn
import torch.nn.parallel
from torch.autograd import Variable
from collections import OrderedDict
import torch.nn.functional as F
from flgc import Flgc2d
from SCNet import *
from fft_conv import fft_conv, FFTConv2d, FFT_Conv2d, pos_mat
from transformer_fft import *
from ACMIX import ACmix
from network_swinfusion1 import SwinFusion1
from DWT_IDWT_layer import *
from pytorch_wavelets import DWTForward, DWTInverse,DTCWTForward, DTCWTInverse
class LRN(nn.Module):
    def __init__(self, local_size=1, alpha=0.0001, beta=0.75, ACROSS_CHANNELS=False):
        super(LRN, self).__init__()
        self.ACROSS_CHANNELS = ACROSS_CHANNELS
        if self.ACROSS_CHANNELS:
            self.average = nn.AvgPool3d(kernel_size=(local_size, 1, 1),
                                        stride=1,
                                        padding=(int((local_size - 1.0) / 2), 0, 0))
        else:
            self.average = nn.AvgPool2d(kernel_size=local_size,
                                        stride=1,
                                        padding=int((local_size - 1.0) / 2))
        self.alpha = alpha
        self.beta = beta

    def forward(self, x):
        if self.ACROSS_CHANNELS:
            div = x.pow(2).unsqueeze(1)
            div = self.average(div).squeeze(1)
            div = div.mul(self.alpha).add(2.0).pow(self.beta)
        else:
            div = x.pow(2)
            div = self.average(div)
            div = div.mul(self.alpha).add(2.0).pow(self.beta)
        x = x.div(div)
        return x
class Fusion_transformer_Net(nn.Module):
    def __init__(self):
        super(Fusion_transformer_Net, self).__init__()
        self.padding1 = nn.ReflectionPad2d((1,1,1,1))
        # self.padding2 = nn.ReflectionPad2d((2, 2, 2, 2))
        # self.padding3 = nn.ReflectionPad2d((3, 3, 3, 3))
        self.conv1_1 = nn.Sequential(nn.Conv2d(1, 16, 3,1,0),
                                     LRN(),
                                     nn.ReLU())
        self.conv1_2 = nn.Sequential(ACmix(16, 32),
                                     LRN(),
                                     nn.ReLU())
        self.conv1_3 = nn.Sequential(ACmix(32, 48),
                                     LRN(),
                                     nn.ReLU())
        self.conv2_1 = nn.Sequential(nn.Conv2d(1, 16, 3,1,0),
                                     LRN(),
                                     nn.ReLU())
        self.conv2_2 = nn.Sequential(ACmix(16, 32),
                                     LRN(),
                                     nn.ReLU())
        self.conv2_3 = nn.Sequential(ACmix(32, 48),
                                     LRN(),
                                     nn.ReLU())
        self.dwt_1=DWT_2D('haar')
        # self.dwt_2 = DWT_2D('haar')
        self.idwt = IDWT_2D('haar')
        # self.mhsa = MHSA(64, 2)
        self.sigmoid = nn.Sigmoid()
        self.concat_ll =nn.Conv2d(96, 48, 1,1,0)
        self.concat_lh = nn.Conv2d(96, 48, 1, 1, 0)
        self.concat_hl = nn.Conv2d(96, 48, 1,1,0)
        self.concat_hh = nn.Conv2d(96, 48, 1,1,0)
        self.conv3_1 = nn.Sequential(nn.Conv2d(48, 32, 3,1,0),
                                     # LRN(),
                                     nn.ReLU())
        self.conv3_2 = nn.Sequential(nn.Conv2d(32, 16, 3,1,0),
                                     # LRN(),
                                     nn.ReLU())
        self.conv3_3 = nn.Conv2d(16, 1, 3,1,0)

    def forward(self, infrared, visible):
        conv1_1 = self.conv1_1(self.padding1(infrared))
        conv2_1 = self.conv2_1(self.padding1(visible))
        conv1_2 = self.conv1_2(conv1_1)
        conv2_2 = self.conv2_2(conv2_1)
        # conv1_2 = torch.cat((conv1_1, conv1_2),dim=1)
        # conv2_2 = torch.cat((conv2_2, conv2_1),dim=1)
        conv1_3 = self.conv1_3(conv1_2)
        conv2_3 = self.conv2_3(conv2_2)
        # conv1_3 = torch.cat((conv1_2, conv1_3),dim=1)
        # conv2_3 = torch.cat((conv2_2, conv2_3),dim=1)
        dwt_ll_1,dwt_lh_1,dwt_hl_1,dwt_hh_1=self.dwt_1(conv1_3)
        dwt_ll_2,dwt_lh_2,dwt_hl_2,dwt_hh_2 = self.dwt_1(conv2_3)
        # dwt_ll_1,dwt_ll_2 = self.mhsa(dwt_ll_1,dwt_ll_2)
        # dwt_lh_1, dwt_lh_2 = self.mhsa(dwt_lh_1, dwt_lh_2)
        # dwt_hl_1, dwt_hl_2 = self.mhsa(dwt_hl_1, dwt_hl_2)
        # dwt_hh_1, dwt_hh_2 = self.mhsa(dwt_hh_1, dwt_hh_2)

        concate_l1 = self.concat_ll(torch.cat((dwt_ll_1,dwt_ll_2),dim=1))
        concate_ll = self.sigmoid(concate_l1)*dwt_ll_2 + (1-self.sigmoid(concate_l1))*dwt_ll_1
        concate_l2 = self.concat_lh(torch.cat((dwt_lh_1,dwt_lh_2),dim=1))
        concate_lh = self.sigmoid(concate_l2)*dwt_lh_2 + (1-self.sigmoid(concate_l2))*dwt_lh_1
        concate_h1 = self.concat_hl(torch.cat((dwt_hl_1,dwt_hl_2),dim=1))
        concate_hl = self.sigmoid(concate_h1)*dwt_hl_2 + (1-self.sigmoid(concate_h1))*dwt_hl_1
        concate_h2 = self.concat_hh(torch.cat((dwt_hh_1,dwt_hh_2),dim=1))
        concate_hh = self.sigmoid(concate_h2)*dwt_hh_2 + (1-self.sigmoid(concate_h2))*dwt_hh_1
        concate = self.idwt(concate_ll, concate_lh, concate_hl, concate_hh)
        # concate=torch.cat((conv1_3, conv2_3),dim=1)
        conv3_1 = self.conv3_1(self.padding1(concate))
        conv3_2 = self.conv3_2(self.padding1(conv3_1))
        conv3_3 = self.conv3_3(self.padding1(conv3_2))
        #conv3_4 = self.conv3_4(conv3_3)
        return conv3_3
class Fusion_transformer_Net_ab1(nn.Module):
    def __init__(self):
        super(Fusion_transformer_Net_ab1, self).__init__()
        self.padding1 = nn.ReflectionPad2d((1,1,1,1))
        # self.padding2 = nn.ReflectionPad2d((2, 2, 2, 2))
        # self.padding3 = nn.ReflectionPad2d((3, 3, 3, 3))
        self.conv1_1 = nn.Sequential(nn.Conv2d(1, 16, 3,1,0),
                                     LRN(),
                                     nn.ReLU())
        self.conv1_2 = nn.Sequential(nn.Conv2d(16, 32, 3,1,0),
                                     LRN(),
                                     nn.ReLU())
        self.conv1_3 = nn.Sequential(nn.Conv2d(32, 48, 3,1,0),
                                     LRN(),
                                     nn.ReLU())
        self.conv2_1 = nn.Sequential(nn.Conv2d(1, 16, 3,1,0),
                                     LRN(),
                                     nn.ReLU())
        self.conv2_2 = nn.Sequential(nn.Conv2d(16, 32, 3,1,0),
                                     LRN(),
                                     nn.ReLU())
        self.conv2_3 = nn.Sequential(nn.Conv2d(32, 48, 3,1,0),
                                     LRN(),
                                     nn.ReLU())

        self.sigmoid = nn.Sigmoid()
        self.concat_hh = nn.Conv2d(96, 48, 1,1,0)
        self.conv3_1 = nn.Sequential(nn.Conv2d(48, 32, 3,1,0),
                                     # LRN(),
                                     nn.ReLU())
        self.conv3_2 = nn.Sequential(nn.Conv2d(32, 16, 3,1,0),
                                     # LRN(),
                                     nn.ReLU())
        self.conv3_3 = nn.Conv2d(16, 1, 3,1,0)

    def forward(self, infrared, visible):
        conv1_1 = self.conv1_1(self.padding1(infrared))
        conv2_1 = self.conv2_1(self.padding1(visible))
        conv1_2 = self.conv1_2(self.padding1(conv1_1))
        conv2_2 = self.conv2_2(self.padding1(conv2_1))
        conv1_3 = self.conv1_3(self.padding1(conv1_2))
        conv2_3 = self.conv2_3(self.padding1(conv2_2))
        concate=self.concat_hh(torch.cat((conv1_3, conv2_3),dim=1))
        concate_hh = self.sigmoid(concate)*conv2_3 + (1-self.sigmoid(concate))*conv1_3
        conv3_1 = self.conv3_1(self.padding1(concate_hh))
        conv3_2 = self.conv3_2(self.padding1(conv3_1))
        conv3_3 = self.conv3_3(self.padding1(conv3_2))
        #conv3_4 = self.conv3_4(conv3_3)
        return conv3_3
class Pos2Weight(nn.Module):
    def __init__(self, inC, outC, kernel_size=3):
        super(Pos2Weight,self).__init__()
        self.inC = inC
        self.outC = outC
        self.kernel_size=kernel_size
        self.meta_block=nn.Sequential(
            nn.Linear(3, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, self.kernel_size*self.kernel_size*self.inC*self.outC)
        )

    def forward(self, x):
        output = self.meta_block(x)

        return output


class MHSA(nn.Module):
    def __init__(self, n_dims, heads=2):
        super(MHSA, self).__init__()
        self.heads = heads

        self.query = nn.Sequential(OrderedDict([('q', nn.Sequential(nn.Conv2d(n_dims, n_dims, kernel_size=1)))]))
        self.key = nn.Sequential(OrderedDict([('k', nn.Sequential(nn.Conv2d(n_dims, n_dims, kernel_size=1)))]))
        self.value = nn.Sequential(OrderedDict([('v', nn.Sequential(nn.Conv2d(n_dims, n_dims, kernel_size=1)))]))

        self.query1 = nn.Sequential(OrderedDict([('q1', nn.Sequential(nn.Conv2d(n_dims, n_dims, kernel_size=1)))]))
        self.key1 = nn.Sequential(OrderedDict([('k1', nn.Sequential(nn.Conv2d(n_dims, n_dims, kernel_size=1)))]))
        self.value1 = nn.Sequential(OrderedDict([('v1', nn.Sequential(nn.Conv2d(n_dims, n_dims, kernel_size=1)))]))

        self.softmax = nn.Softmax(dim=-1)

    def forward(self, x, x1):
        n_batch, C, width, height = x.size()
        q = self.query(x).view(n_batch, self.heads, C // self.heads, -1)
        k = self.key(x).view(n_batch, self.heads, C // self.heads, -1)
        v = self.value(x).view(n_batch, self.heads, C // self.heads, -1)

        q1 = self.query1(x1).view(n_batch, self.heads, C // self.heads, -1)
        k1 = self.key1(x1).view(n_batch, self.heads, C // self.heads, -1)
        v1 = self.value1(x1).view(n_batch, self.heads, C // self.heads, -1)

        content_content = torch.matmul(q.permute(0, 1, 3, 2), k1)

        energy = (content_content) * (1.0 / math.sqrt(k.size(-1)))
        attention = self.softmax(energy)

        out = torch.matmul(v1, attention.permute(0, 1, 3, 2))
        out = out.view(n_batch, C, width, height)

        content_content1 = torch.matmul(q1.permute(0, 1, 3, 2), k)

        energy1 = (content_content1) * (1.0 / math.sqrt(k.size(-1)))
        attention1 = self.softmax(energy1)

        out1 = torch.matmul(v, attention1.permute(0, 1, 3, 2))
        out1 = out1.view(n_batch, C, width, height)

        return out+x, out1+x1
class MetaLearner(nn.Module):
    def __init__(self):
        super(MetaLearner, self).__init__()
        self.P2W = Pos2Weight(inC=48, outC=48)

    def repeat_x(self, x, r_int):
        N, C, H, W = x.size()
        x = x.view(N, C, H, 1, W, 1)
        x = torch.cat([x] * r_int, 3)
        x = torch.cat([x] * r_int, 5).permute(0, 3, 5, 1, 2, 4)

        return torch.reshape(x, (-1, C, H, W))

    def forward(self, x, r, pos_mat, mask, HRsize):
        # torch.cuda.empty_cache()
        scale_int = math.ceil(r)
        outC = x.size(1)
        local_weight = self.P2W(pos_mat.view(pos_mat.size(1), -1))
        up_x = self.repeat_x(x, scale_int)
        cols = nn.functional.unfold(up_x, kernel_size=3, padding=1)
        cols = torch.reshape(cols, (cols.size(0) // (scale_int ** 2), scale_int ** 2, cols.size(1), cols.size(2), 1)).permute(0, 1, 3, 4, 2)
        local_weight = torch.reshape(local_weight, (x.size(2), scale_int, x.size(3), scale_int, -1, outC)).permute(1,3,0,2,4,5)
        local_weight = torch.reshape(local_weight, (scale_int ** 2, x.size(2) * x.size(3), -1, outC))
        out = torch.matmul(cols, local_weight)
        out = out.permute(0, 1, 4, 2, 3)
        out = torch.reshape(out, (x.size(0), scale_int, scale_int, outC, x.size(2), x.size(3))).permute(0, 3, 4, 1, 5, 2)
        out = torch.reshape(out, (x.size(0), outC, scale_int * x.size(2), scale_int * x.size(3)))

        re_sr = torch.masked_select(out, mask)
        re_sr = torch.reshape(re_sr, (x.size(0), outC, HRsize[0], HRsize[1]))
        torch.cuda.empty_cache()

        return re_sr